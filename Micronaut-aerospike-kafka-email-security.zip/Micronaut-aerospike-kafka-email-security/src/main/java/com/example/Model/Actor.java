package com.example.Model;

import com.aerospike.mapper.annotations.AerospikeBin;
import com.aerospike.mapper.annotations.AerospikeEmbed;
import com.aerospike.mapper.annotations.AerospikeKey;
import com.aerospike.mapper.annotations.AerospikeRecord;

@AerospikeRecord(namespace = "test",set = "Actor")
public class Actor {
    @AerospikeKey

    @AerospikeBin
    private int id;
    @AerospikeBin
    private String aName;
    @AerospikeBin
    private String aEmail;
    @AerospikeBin
    private  int aSal;
    @AerospikeBin
    private String aDob;

    @AerospikeEmbed
    @AerospikeBin
    private Movies movies;

    public Actor(int id, String aName, String aEmail, int aSal, String aDob, Movies movies) {
        this.id = id;
        this.aName = aName;
        this.aEmail = aEmail;
        this.aSal = aSal;
        this.aDob = aDob;
        this.movies = movies;
    }

    public Actor() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getaName() {
        return aName;
    }

    public void setaName(String aName) {
        this.aName = aName;
    }

    public String getaEmail() {
        return aEmail;
    }

    public void setaEmail(String aEmail) {
        this.aEmail = aEmail;
    }

    public int getaSal() {
        return aSal;
    }

    public void setaSal(int aSal) {
        this.aSal = aSal;
    }

    public String getaDob() {
        return aDob;
    }

    public void setaDob(String aDob) {
        this.aDob = aDob;
    }

    public Movies getMovies() {
        return movies;
    }

    public void setMovies(Movies movies) {
        this.movies = movies;
    }

    @Override
    public String toString() {
        return "Actor{" +
                "id=" + id +
                ", aName='" + aName + '\'' +
                ", aEmail='" + aEmail + '\'' +
                ", aSal=" + aSal +
                ", aDob='" + aDob + '\'' +
                ", movies=" + movies +
                '}';
    }
}
