package com.example.Model;

import com.aerospike.mapper.annotations.AerospikeRecord;

@AerospikeRecord
public class Movies {
    private int mid;
    private  String mname;

    public Movies(int mid, String mname) {
        this.mid = mid;
        this.mname = mname;
    }

    public Movies() {
    }

    public int getMid() {
        return mid;
    }

    public void setMid(int mid) {
        this.mid = mid;
    }

    public String getMname() {
        return mname;
    }

    public void setMname(String mname) {
        this.mname = mname;
    }

    @Override
    public String toString() {
        return "Movies{" +
                "mid=" + mid +
                ", mname='" + mname + '\'' +
                '}';
    }
}
