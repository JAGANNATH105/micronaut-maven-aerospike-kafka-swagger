package com.example.Repository;

import com.example.Model.Actor;

import java.util.List;

public interface ActorRepository {
    public String addActor(Actor actor);


    public List<Actor> getAllActor();

    public Actor findById(int id);

    public String updateActor(Actor actor, int id);
    public String deleteById(int id);
}
