package com.example.controller;

import com.example.Model.Actor;
import com.example.Model.CustomResponse;
import com.example.Service.ActorService;
import io.micronaut.http.HttpResponse;
import io.micronaut.http.HttpStatus;
import io.micronaut.http.MediaType;
import io.micronaut.http.annotation.*;
import io.micronaut.security.annotation.Secured;
import io.micronaut.security.rules.SecurityRule;
import jakarta.inject.Inject;

import java.util.List;


@Controller("/actor")
@Secured(SecurityRule.IS_AUTHENTICATED)
public class ActorController {
    @Inject
    ActorService actorService;

    @Post("/add")
    @Produces(MediaType.APPLICATION_JSON)
    public HttpResponse<CustomResponse> AddActor(@Body Actor actor) {
        return HttpResponse.ok(new CustomResponse(actorService.addActor(actor)));
    }


    @Get("/show")
    @Produces(MediaType.APPLICATION_JSON)
    public HttpResponse<List<Actor>> getActor() {
        List<Actor> act = actorService.getAllActor();

        if (act.size() >= 0) {
            return HttpResponse.ok().body(act);
        }
        return HttpResponse.status(HttpStatus.INTERNAL_SERVER_ERROR);
    }


    @Get("/show/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public HttpResponse<Actor> getActorById(@PathVariable int id){
        Actor act = actorService.findById(id);

        if(act != null){
            return HttpResponse.ok().body(act);
        }
        else
            return HttpResponse.status(HttpStatus.NOT_FOUND);
    }


    @Delete("/delete/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public HttpResponse<CustomResponse> deleteActorById(@PathVariable int id){
        return HttpResponse.ok(new CustomResponse(actorService.deleteById(id)));
    }


    @Put("/update/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public HttpResponse<CustomResponse> updateActorById(@Body Actor actor,@PathVariable int id){
        return HttpResponse.ok(new CustomResponse(actorService.updateActor(actor,id)));
    }
}
