package com.example.Service;
import com.example.Configuration.aeroMapperConfig;
import com.example.Email.EmailDetails;
import com.example.Model.Actor;
import com.example.Repository.ActorRepository;
import jakarta.inject.Inject;
import jakarta.inject.Singleton;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.serialization.IntegerSerializer;
import org.apache.kafka.common.serialization.StringSerializer;

import java.util.List;
import java.util.Properties;

@Singleton
public class ActorService implements ActorRepository {

    @Inject
    aeroMapperConfig mapper;
    @Inject
    EmailService emailService;

    static final Object BOOTSTRAP_SERVERS = "localhost:9092";
    static final String TOPIC = "Actor";



    @Override
    public String addActor(Actor actor) {
        mapper.getMapper().save(actor);
        Properties producerProperties = new Properties();
        producerProperties.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, BOOTSTRAP_SERVERS);
        producerProperties.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, IntegerSerializer.class);
        producerProperties.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class);


        KafkaProducer<Integer, String> kafkaProducer = new KafkaProducer(producerProperties);

        ProducerRecord<Integer, String> record = new ProducerRecord<>(TOPIC,"Message-"+"Person Data Added..!="+" "+actor);
        kafkaProducer.send(record);
        kafkaProducer.close();
        EmailService.sendEmail(new EmailDetails("Actor Information Alert !!!", "Congratulations , Actor Info added "+actor.getaName()+", Your Actor Id is "+actor.getId(), actor.getaEmail()));
        return "Actor saved successfully..!="+actor.getId();
    }

    @Override
    public List<Actor> getAllActor() {
        Properties producerProperties = new Properties();
        producerProperties.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, BOOTSTRAP_SERVERS);
        producerProperties.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, IntegerSerializer.class);
        producerProperties.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class);


        KafkaProducer<Integer, String> kafkaProducer = new KafkaProducer(producerProperties);

        ProducerRecord<Integer, String> record = new ProducerRecord<>(TOPIC,"Message-"+"Get All Actor Data...!="+" "+Actor.class);
        kafkaProducer.send(record);
        kafkaProducer.close();
        return mapper.getMapper().scan(Actor.class);

    }

    @Override
    public Actor findById(int id) {
        Properties producerProperties = new Properties();
        producerProperties.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, BOOTSTRAP_SERVERS);
        producerProperties.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, IntegerSerializer.class);
        producerProperties.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class);


        KafkaProducer<Integer, String> kafkaProducer = new KafkaProducer(producerProperties);

        ProducerRecord<Integer, String> record = new ProducerRecord<>(TOPIC,"Message-"+"Get Actor Data by Id..!="+" "+id);
        kafkaProducer.send(record);
        kafkaProducer.close();

        return mapper.getMapper().read(Actor.class, id);
    }

    @Override
    public String updateActor(Actor actor, int id) {
        Actor a=mapper.getMapper().read(Actor.class,id);
        a.setaName(actor.getaName());
        a.setaEmail(actor.getaEmail());
        a.setaDob(actor.getaDob());
        a.setaSal(actor.getaSal());
        a.setMovies(actor.getMovies());
        mapper.getMapper().save(a);
        Properties producerProperties = new Properties();
        producerProperties.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, BOOTSTRAP_SERVERS);
        producerProperties.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, IntegerSerializer.class);
        producerProperties.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class);


        KafkaProducer<Integer, String> kafkaProducer = new KafkaProducer(producerProperties);

        ProducerRecord<Integer, String> record = new ProducerRecord<>(TOPIC,"Message-"+"Person Data Updated"+" "+actor);
        kafkaProducer.send(record);
        kafkaProducer.close();
        EmailService.sendEmail(new EmailDetails("Person Information Alert !!!", "Congratulations, Person Info updated..!= "+actor.getaName()+", Your Person Id is "+actor.getId(), actor.getaEmail()));
        return "Actor Updated..!="+a.getId();    }

    @Override
    public String deleteById(int id) {
        mapper.getMapper().delete(Actor.class,id);
        Properties producerProperties = new Properties();
        producerProperties.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, BOOTSTRAP_SERVERS);
        producerProperties.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, IntegerSerializer.class);
        producerProperties.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class);


        KafkaProducer<Integer, String> kafkaProducer = new KafkaProducer(producerProperties);


        ProducerRecord<Integer, String> record = new ProducerRecord<>(TOPIC,"Message-"+"Actor Data Deleted By Id..!="+" "+id);
        kafkaProducer.send(record);
        kafkaProducer.close();
        return "Actor Deleted By Id..!="+id;
    }
}
