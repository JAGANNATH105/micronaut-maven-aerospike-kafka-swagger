package com.example.controller;

import io.micronaut.test.extensions.junit5.annotation.MicronautTest;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
@MicronautTest
class ActorControllerTest {

    @Test
    void addActor() {
    }

    @Test
    void getActor() {
    }

    @Test
    void getActorById() {
    }

    @Test
    void deleteActorById() {
    }

    @Test
    void updateActorById() {
    }
}