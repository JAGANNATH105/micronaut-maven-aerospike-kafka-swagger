//package com.example.Service;
//
//import com.example.Configuration.aeroMapperConfig;
//import com.example.Model.Actor;
//import com.example.Model.Movies;
//import com.example.Repository.ActorRepository;
//import io.micronaut.test.extensions.junit5.annotation.MicronautTest;
//import jakarta.inject.Inject;
//import org.junit.jupiter.api.Assertions;
//import org.junit.jupiter.api.Test;
//
//import static org.junit.jupiter.api.Assertions.*;
//
//@MicronautTest
//class ActorServiceTest {
//
//    @Inject
//    ActorRepository actorRepository;
//    @Inject
//    aeroMapperConfig mapper;
//    @Test
//    void addActor() {
//        Actor actor=new Actor(11,"salman khan","salmankhan@gmail.com",1234,"2021-12-31",new Movies(11,"ready"));
//
//        Assertions.assertEquals(actorRepository.addActor(actor), "Actor saved successfully..!="+actor.getId());
//
//    }
//
//    @Test
////    void getAllActor() {
////        Assertions.assertEquals(actorRepository.getAllActor(), mapper.getMapper().scan(Actor.class));
////
////    }
//
//    @Test
//    void findById() {
//        int id=55;
//        Assertions.assertEquals(actorRepository.findById(id), mapper.getMapper().read(Actor.class, id));
//
//    }
//
//    @Test
//    void updateActor() {
//        Actor actor=new Actor();
//                actor.setaName("salman khan");
//        actor.setaSal(1234);
//        actor.setaEmail("salmankhan@gmail.com");
//
//        actor.setaDob("2021-12-31");
//        Movies movies=new Movies(11,"ready");
//        actor.setMovies(movies);
//        Assertions.assertEquals(actorRepository.updateActor(actor,11), "Actor Updated..!="+11);
//
//    }
//
//    @Test
//    void deleteById() {
//        int id=11;
//        Assertions.assertEquals(actorRepository.deleteById(id), "Actor Deleted By Id..!="+id);
//
//    }
//}